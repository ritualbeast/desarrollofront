import React from 'react'

const ReporteEstadisticoIPN = () => {
  return (
    <div>
      <h1>Reporte Estadistico</h1>
    </div>
  )
}

export default ReporteEstadisticoIPN
