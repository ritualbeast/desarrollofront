import React from 'react'

const ModalEliminarSeccion = () => {
  return (
    <>
        <div style={{textAlign: 'center'}}>
            ¿Desea eliminar la sección seleccionada?
        </div>
    </>
  )
}

export default ModalEliminarSeccion
