import React from 'react'

const EditarEncuestas = () => {
  return (
    <div>
        <h1>Editar Encuestas</h1>
      
    </div>
  )
}

export default EditarEncuestas
