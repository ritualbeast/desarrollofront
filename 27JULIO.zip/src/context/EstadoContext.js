
// import React, { useContext, useState } from 'react';

// const EstadoContext = React.createContext();

// export const useEstadoContext = () => useContext(EstadoContext);

// export const EstadoProvider = ({ children }) => {
//   const  [previewContext, setPreviewContext]  = useEstadoContext();
//   return (
//     <EstadoContext.Provider value={{ previewContext }}>
//       {children}
//     </EstadoContext.Provider>
//   );
// };