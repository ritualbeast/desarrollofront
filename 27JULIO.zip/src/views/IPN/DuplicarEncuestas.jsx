import React from 'react'

const DuplicarEncuestas = () => {
  return (
    <div>
        <h1>Duplicar Encuestas</h1>
    </div>
  )
}

export default DuplicarEncuestas
 