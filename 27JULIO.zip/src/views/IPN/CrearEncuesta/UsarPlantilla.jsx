import React from 'react'

const UsarPlantilla = () => {
  return (
    <div>
      Usa una plantilla predefinida
    </div>
  )
}

export default UsarPlantilla
