import React from 'react'

const EliminarEncuestas = () => {
  return (
    <div>
        <h1>Eliminar Encuestas</h1>
    </div>
  )
}

export default EliminarEncuestas
