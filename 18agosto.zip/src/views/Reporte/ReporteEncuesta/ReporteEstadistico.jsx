import React from 'react'

const ReporteEstadistico = () => {
  return (
    <div>
      <h1>Reporte Estadistico</h1>
    </div>
  )
}

export default ReporteEstadistico
