import React from 'react'

const ModalEliminarPregunta = () => {
  return (
    <>
        <div style={{textAlign: 'center'}}>
            ¿Desea eliminar la pregunta seleccionada?
        </div>
    </>
  )
}

export default ModalEliminarPregunta
